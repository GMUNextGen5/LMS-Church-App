Assessments, Classes & Grading — extracted module bundle
=========================================================

This ZIP contains only the source files and directories for:
  • Assessments (create/edit/take assessments, questions, submissions, auto-grading)
  • Classes (courses, roster, teacher assignment)
  • Grading (grades CRUD, listenToGrades, export CSV, assessment grading/release)

Structure (mirrors project src/):
  src/
    core/     — config, firebase, auth, types (shared dependencies)
    data/     — data.ts (students, grades, attendance, courses), assessment-data.ts, classes-data.ts
    ui/       — ui.ts (loading, modals), assessment-ui.ts, classes-ui.ts
  vite-env.d.ts

Dependencies included so the bundle is self-contained for reference or reuse.
Excluded: main.ts, particles, index.html, functions/, public/, and all other project files.

Extract and use paths as in the main project (e.g. from '../core/firebase').
